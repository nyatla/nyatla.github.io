# geoBoundaries CGAZ / 1/100 degree on ESP32 DevKitC / 4MB

Galuchat C++ Readerと端末内のWGSMapSet/GisWordBookだけで逆ジオコーディングする
自己完結Arduinoプロジェクトです。外部の地図APIやデータベースは使用しません。

## Build target

- Platform: `esp32_4mb`
- Arduino FQBN: `esp32:esp32:esp32`
- Flash: 4194304 bytes
- C++ exceptions: required
- Dataset: `geoboundaries_100`
- Experimental capacity check: true

Arduino IDEでこのディレクトリと同名の`.ino`を開いてください。シリアルモニタは
115200bpsです。起動時にサンプル地点を検索し、その後は`longitude latitude`形式で
任意の座標を入力できます。

データの出典・利用条件は配布ページのDATA-NOTICEを確認してください。

