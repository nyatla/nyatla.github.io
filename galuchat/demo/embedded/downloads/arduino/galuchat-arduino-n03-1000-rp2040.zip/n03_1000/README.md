# N03 2026 / 1/1000 degree on Raspberry Pi Pico / RP2040

Galuchat C++ Readerと端末内のWGSMapSet/GisWordBookだけで逆ジオコーディングする
自己完結Arduinoプロジェクトです。外部の地図APIやデータベースは使用しません。

## Build target

- Platform: `rp2040`
- Arduino FQBN: `rp2040:rp2040:rpipico`
- Flash: 2097152 bytes
- C++ exceptions: required
- Dataset: `n03_1000`
- Experimental capacity check: false

Arduino IDEでこのディレクトリと同名の`.ino`を開いてください。シリアルモニタは
115200bpsです。起動時にサンプル地点を検索し、その後は`longitude latitude`形式で
任意の座標を入力できます。

データの出典・利用条件は配布ページのDATA-NOTICEを確認してください。

