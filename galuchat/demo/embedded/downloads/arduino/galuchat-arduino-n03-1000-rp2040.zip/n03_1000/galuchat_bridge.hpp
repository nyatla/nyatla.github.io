#pragma once

#include "wgsmap3_reader.hpp"
#include "gis_wordbook_reader.hpp"
#include "mapset.hpp"
#include "wordbook.hpp"

namespace galuchat::embedded_demo {

inline std::shared_ptr<const ReaderFactory> mapsetReaderFactory() {
    return std::make_shared<BufferReaderFactory>(mapset, mapset_size);
}

inline std::shared_ptr<const ReaderFactory> wordbookReaderFactory() {
    return std::make_shared<BufferReaderFactory>(wordbook, wordbook_size);
}

} // namespace galuchat::embedded_demo
